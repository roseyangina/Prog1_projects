Temporarily hosting https://github.com/uf-cise-cs1/gatorraider
